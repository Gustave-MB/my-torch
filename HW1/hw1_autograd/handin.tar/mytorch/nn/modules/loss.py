import numpy as np
from mytorch.nn.functional_hw1 import (
    matmul_backward,
    add_backward,
    sub_backward,
    mul_backward,
    div_backward,
    SoftmaxCrossEntropy_backward,
)


class LossFN(object):
    """
    Interface for loss functions.

    The class serves as an abstract base class for different loss functions.
    The forward() method should be completed by the derived classes.

    This class is similar to the wrapper functions for the activations
    that you wrote in functional.py with a couple of key differences:
        1. Notice that instead of passing the autograd object to the forward
            method, we are instead saving it as a class attribute whenever
            an LossFN() object is defined. This is so that we can directly
            call the backward() operation on the loss as follows:
                >>> loss_fn = LossFN(autograd_object)
                >>> loss_val = loss_fn(y, y_hat)
                >>> loss_fn.backward()

        2. Notice that the class has an attribute called self.loss_val.
            You must save the calculated loss value in this variable.
            This is so that we do not explicitly pass the divergence to
            the autograd engine's backward method. Rather, calling backward()
            on the LossFN object will take care of that for you.

    WARNING: DO NOT MODIFY THIS CLASS!
    """

    def __init__(self, autograd_engine):
        self.autograd_engine = autograd_engine
        self.loss_val = None

    def __call__(self, y, y_hat):
        return self.forward(y, y_hat)

    def forward(self, y, y_hat):
        """
        Args:
            - y (np.ndarray) : the ground truth,
            - y_hat (np.ndarray) : the output computed by the network,

        Returns:
            - self.loss_val : the calculated loss value
        """
        raise NotImplementedError

    def backward(self):
        # Call autograd's backward here.
        self.autograd_engine.backward(self.loss_val)


class MSELoss(LossFN):
    def __init__(self, autograd_engine):
        super(MSELoss, self).__init__(autograd_engine)

    def forward(self, y, y_hat):
        # TODO: Use the primitive operations to calculate the MSE Loss
        # TODO: Remember to use add_operation to record these operations in
        #       the autograd engine after each operation

        # self.loss_val = ...
        # return self.loss_val


        # Calculate the Mean Squared Error (MSE) loss
        squared_error = (y - y_hat) ** 2
        self.loss_val = np.mean(squared_error)

        # Record this operation in the autograd engine
        self.autograd_engine.add_operation([y, y_hat], self.loss_val, [None, None], sub_backward)

        return self.loss_val

# Hint: To simplify things you can just make a backward for this loss and not
# try to do it for every operation.
class SoftmaxCrossEntropy(LossFN):
    def __init__(self, autograd_engine):
        super(SoftmaxCrossEntropy, self).__init__(autograd_engine)

    def forward(self, y, y_hat):
        # TODO: calculate loss value and set self.loss_val
        # To simplify things, add a single operation corresponding to the
        # backward function created for this loss

        # self.loss_val = ...
        # return self.loss_val
        # Calculate the Softmax Cross-Entropy loss
        max_y_hat = np.max(y_hat, axis=0, keepdims=True)
        exp_y_hat = np.exp(y_hat - max_y_hat)
        softmax_y_hat = exp_y_hat / np.sum(exp_y_hat, axis=0, keepdims=True)
        self.loss_val = -np.sum(y * np.log(softmax_y_hat))

        # Record this operation in the autograd engine
        self.autograd_engine.add_operation([y_hat], self.loss_val, [None], SoftmaxCrossEntropy_backward)

        return self.loss_val